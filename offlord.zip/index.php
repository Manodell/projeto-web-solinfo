<?php include("header.php");?>
<section>
<!-- INICIO DO SLIDE HOME PRINCIPAL   -->
    <div id="slider1_container">
        <!-- Loading Screen -->
        <div u="loading" class="loading">
            <div class="loading-icon1">
            </div>
            <div class="loading-icon2">
            </div>
        </div>
        <!-- Slides Container -->
        <div u="slides" class="u-slides">
            <div>
                <img u="image" src="images/slider1.png"/>
                <div class="u-slides-cabecalho">algo aqui
                </div>
                <div class="u-slides-texto">
                    A melhor Escolha em roupas femininas.
                </div>
            </div>
            <div>
                <img u="image" src="images/purple.jpg"/>
                <div class="u-slides-cabecalho">Off Lord Jeans
                </div>
                <div  class="u-slides-texto">
                    Roupas de ótima qualidade.
                </div>
            </div>
            <div>
                <img u="image" src="images/blue.jpg"/>
                <div class="u-slides-cabecalho">
                    <!--                Texto principal do slide -->
                    Texto. do slide.
                </div>
                <div  class="u-slides-texto">
                    Texto escolhido pelo ciente para ser inserido
                </div>
            </div>
        </div>
        <!-- bullet navigator container -->
        <div u="navigator" class="jssorb21">
            <!-- bullet navigator item prototype -->
            <div u="prototype"></div>
        </div>
        <!-- Bullet Navigator Skin End -->
        <!-- Arrow Left -->
    <span u="arrowleft" class="jssora21l">
    </span>
        <!-- Arrow Right -->
    <span u="arrowright" class="jssora21r">
    </span>
        <!-- Arrow Navigator Skin End -->
    </div>
    <!-- FINALIZAÇÃO DO CÓDIGO DO SLIDER PRINCIPAL -->
</section>

<section id="columns">
    <div class="container">
        <div class="row">
<section class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div id="content">
<div class=" block productcarousel" id="module5707280431419958629">
<div class="block-title">
    <h3>Produtos em Ofertas</h3>

    <div class="pretext"></div>
</div>
<div class="block-content">
<div class="box-products carousel" id="productcarousel5707280431419958629">
<div class="carousel-inner">

<div class="item first active product-grid no-margin">

<div class="row products-row">

<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item first ">
    <div class="wrap-item">
        <div class="product-block">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product002_2.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart"
                                onclick="addToCart('Produto')">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item product-col  ">
    <div class="wrap-item">
        <div class="product-block">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product006_1.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart"
                                onclick="addToCart('Produto')">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item product-col  ">
    <div class="wrap-item">
        <div class="product-block">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product003_4.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart"
                                onclick="addToCart('Produto')">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item last product-col  ">
    <div class="wrap-item">
        <div class="product-block">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product001.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>



</div>

</div>

</div>
</div>
</div>
</div>

<div class="productcarousel2 block productcarousel" id="module670609331419958630">
<div class="block-title">
    <h3>MAIS VISTOS</h3>

    <div class="pretext"></div>
</div>
<div class="block-content">
<div class="box-products carousel" id="productcarousel2670609331419958630">
<div class="carousel-inner">

<div class="item first active product-grid no-margin">

<div class="row products-row">

<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item first ">
    <div class="wrap-item">
        <div class="product-block block2">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product007.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item product-col  ">
    <div class="wrap-item">
        <div class="product-block block2">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product004_3.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart"
                                onclick="addToCart('Produto')">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item product-col  ">
    <div class="wrap-item">
        <div class="product-block block2">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product019_1.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


<div class="col-xs-12 col-lg-3 col-sm-6 col-6 _item last product-col  ">
    <div class="wrap-item">
        <div class="product-block block2">
            <div class="image ">
                <div class="product-img img">
                    <a href="produto.php"
                       title="Detalhes do produto" class="product-image img">


                        <img class="img-responsive"
                             src="images/product008_2.jpg"
                             width="279" height="380" alt="Detalhes do produto"/>

                    </a>


                </div>
                <div class="action">
                    <div class="add-to-cart">
                        <button type="button" title="Comprar" class="btn btn-cart"
                                onclick="addToCart('Produto')">
                            <span>Comprar</span></button>

                    </div>
                    <div class="add-to-link">
                        <a class="a-quickview ves-colorbox" title="Visualização rapida"
                           href="produto.php"><i
                                class="fa fa-eye"></i><span>Visualização rapida </span></a>

                        <a href="carrinho.php"
                           title="Lista de desejos" class="link-wishlist"><i class="fa fa-heart"></i></a>

                    </div>
                </div>
            </div>


            <div class="product-meta product-shop">

                <h3 class="product-name name"><a
                        href="produto.php"
                        title="Exercitationem ullam corporis suscipit">Vestido casual talls</a></h3>

                <div class="price">


                    <div class="price-box">

                        <p class="old-price">
                            <span class="price-label">Preço Regular:</span>
                <span class="price" id="old-price-1_product_carousel_1_5707280431419958629">
                    R$120.00                </span>
                        </p>

                        <p class="special-price">
                            <span class="price-label">Preço Especial</span>
                <span class="price" id="product-price-1_product_carousel_1_5707280431419958629">
                    R$110.00                </span>
                        </p>


                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


</div>

</div>


</div>
</div>
</div>
</div>


</div>
</section>
</div>
</div>
</section>


<section class="contentbottom">
    <div class="container">
        <div class="row custom-static">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="abs-left">
                    <div class="block block-subscribe">
                        <div class="block-title">
                            <h3>Newsletter</h3>
                        </div>
                        <form id="newsletter-validate-detail" method="post" action="new/">
                            <div class="block-content">
                                <div class="form-subscribe-header">
                                    <label for="newsletter">Cadastre-se e receba todas as novidades.</label>
                                </div>
                                <div class="input-box">
                                    <input id="newsletter" class="input-text form-control inputnome" type="text" required="required" title="Seu nome" placeholder="Seu nome..." name="nome" />
                                    <input id="newsletter" class="input-text form-control inputemail" type="email" required="required" title="Seu Email" placeholder="Seu email..." name="email" />
                                </div>
                                <div class="actions">
                                    <button class="btn" title="Cadastre-se" type="submit">
                                        <span>
                                            <span>Cadastre-se</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="abs-right">
                    <div class="block block-cartoes">
                        <div class="block-title">
                            <h3>Facilidade para pagar</h3>

                            <h4>Parcele suas compras</h4>
                        </div>
                        <img src="images/cartoes.png" />
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<?php include("footer.php");?>