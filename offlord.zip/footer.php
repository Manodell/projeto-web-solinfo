<section id="footer">
    <div class="container">
        <div class="row">
            <div class="redes col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <a href="#">
                    <span>Siga, Compartilhe</span>
                </a>
            </div>
            <div class="redes col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <a href="#">
                    <img src="images/facebook-box-blue.png" />
                </a>
                <a href="#">
                    <img src="images/instagram-box.png" />
                </a>

            </div>
            <div class="logo col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <a href="/"><img src="images/logo.png" /></a>
            </div>
            <div class="direitos col-lg-12 col-md-12 col-sm-12 col-xs-12">

                <p><span>Off Lord - Todos os direitos reservados. </span>Rua 67a n 95 SL 01 Setor Norte Ferroviário (62)3213-0334</p>

                <p><a href="/" title="Off Lord">www.offlord.com.br</a></p>
            </div>
        </div>
    </div>
</section>

</section>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</body>

</html>